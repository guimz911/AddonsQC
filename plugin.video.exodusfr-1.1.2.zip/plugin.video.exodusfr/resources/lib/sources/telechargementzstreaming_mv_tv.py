# -*- coding: utf-8 -*-

'''
    Exodus Add-on
    Copyright (C) 2016 Exodus

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import re,urllib,urlparse,time,datetime,unicodedata

from resources.lib.modules import control
from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import debrid


class source:
    def __init__(self):
        print 'INIT'
        self.domains = ['www.telechargementz-streaming.net']
        self.base_link = 'http://www.telechargementz-streaming.net'
        self.search_link = '/index.php?do=search&subaction=search&search_start=1&full_search=1&result_from=1&story=%s&titleonly=3&searchuser=&replyless=0&replylimit=0&searchdate=0&beforeafter=after&sortby=date&resorder=desc&showposts=1&catlist[]=3'


    def movie(self, imdb, title, year):
        print 'MOVIE'
        try:
            title = 'http://www.imdb.com/title/%s' % imdb

            titleFR = client.source(title, headers={'Accept-Language':'fr-FR'})
            titleFR = client.parseDOM(titleFR,'title')[0]
            titleFR = re.sub('(?:\(|\s)\d{4}.+', '', titleFR).strip()
            titleFR = ''.join((c for c in unicodedata.normalize('NFD', titleFR) if unicodedata.category(c) != 'Mn'))

            print 'titleFR 0 = %s' % titleFR

            titleCA = client.source(title, headers={'Accept-Language':'fr-CA'})
            titleCA = client.parseDOM(titleCA,'title')[0]
            titleCA = re.sub('(?:\(|\s)\d{4}.+', '', titleCA).strip()
            titleCA = ''.join((c for c in unicodedata.normalize('NFD', titleCA) if unicodedata.category(c) != 'Mn'))

            print 'titleCA 0 = %s' % titleCA

            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except:
            return


    def tvshow(self, imdb, tvdb, tvshowtitle, year):
        print 'TVSHOW'
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except:
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        print 'EPISODE'
        try:
            if url == None: return

            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urllib.urlencode(url)
            return url
        except:
            return


    def sources(self, url, hostDict, hostprDict):
        print 'SOURCES'
        try:
            sources = []
            queryList = []
            titleFRsplit = None
            titleCAsplit = None

            if url == None: return sources

            if debrid.status() == False: raise Exception()

            dt = int(datetime.datetime.now().strftime('%Y%m%d'))
            mt = {'jan':'1', 'feb':'2', 'mar':'3', 'apr':'4', 'may':'5', 'jun':'6', 'jul':'7', 'aug':'8', 'sep':'9', 'oct':'10', 'nov':'11', 'dec':'12'}

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            title = 'http://www.imdb.com/title/%s' % data['imdb']
            print 'title = %s' % title

            result = client.source(title, headers={'Accept-Language':'fr-FR'})
            titleFR = client.parseDOM(result,'title')[0]
            titleFR = re.sub('(?:\(|\s)\d{4}.+', '', titleFR).strip()
            titleFR = ''.join((c for c in unicodedata.normalize('NFD', titleFR) if unicodedata.category(c) != 'Mn'))

            if titleFR[-1:] == '.':
                titleFR = titleFR[:-1]

            try:
                titleFR = re.sub('\&amp\;', '', titleFR).strip()
            except:
                pass

            print 'titleFR = %s' % titleFR

            #print '========'
            #print 'result FR    %s =' % result

            try:
                if ' - ' in titleFR:
                    titleFRsplit = titleFR.split(' - ')

                    if '1ere' in titleFRsplit[1]:
                        titleFRsplit[1] = 'partie 1'
                    elif '2e' in titleFRsplit[1]:
                         titleFRsplit[1] = 'partie 2'
                    elif '3e' in titleFRsplit[1]:
                         titleFRsplit[1] = 'partie 3'
                    elif '4e' in titleFRsplit[1]:
                         titleFRsplit[1] = 'partie 4'
                    elif '5e' in titleFRsplit[1]:
                         titleFRsplit[1] = 'partie 5'
                    elif '6e' in titleFRsplit[1]:
                         titleFRsplit[1] = 'partie 6'
                    elif '7e' in titleFRsplit[1]:
                         titleFRsplit[1] = 'partie 7'
                    elif '8e' in titleFRsplit[1]:
                         titleFRsplit[1] = 'partie 8'
                    elif '9e' in titleFRsplit[1]:
                         titleFRsplit[1] = 'partie 9'
                else:
                    titleFRsplit = ''

                print 'titleFRsplit = %s' % titleFRsplit[0]
                print 'titleFRsplit = %s' % titleFRsplit[1]
            except:
                pass


            try:
                imdbDateSortieFR = re.compile('title="See more release dates" >(.+?)\(France\)', re.MULTILINE|re.DOTALL).findall(result)[0].strip()

                print imdbDateSortieFR

                imdbDateSortieFR = imdbDateSortieFR.replace('January', 'Janvier')
                imdbDateSortieFR = imdbDateSortieFR.replace('February', 'Février')
                imdbDateSortieFR = imdbDateSortieFR.replace('March', 'Mars')
                imdbDateSortieFR = imdbDateSortieFR.replace('April', 'Avril')
                imdbDateSortieFR = imdbDateSortieFR.replace('May', 'Mai')
                imdbDateSortieFR = imdbDateSortieFR.replace('June', 'Juin')
                imdbDateSortieFR = imdbDateSortieFR.replace('July', 'Juillet')
                imdbDateSortieFR = imdbDateSortieFR.replace('August', 'Août')
                imdbDateSortieFR = imdbDateSortieFR.replace('September', 'Septembre')
                imdbDateSortieFR = imdbDateSortieFR.replace('October', 'Octobre')
                imdbDateSortieFR = imdbDateSortieFR.replace('November', 'Novembre')
                imdbDateSortieFR = imdbDateSortieFR.replace('December', 'Décembre')
                imdbDateSortieFR = imdbDateSortieFR[-4:]
                print imdbDateSortieFR
            except:
                imdbDateSortieFR = None


            result = client.source(title, headers={'Accept-Language':'fr-CA'})
            titleCA = client.parseDOM(result,'title')[0]
            titleCA = re.sub('(?:\(|\s)\d{4}.+', '', titleCA).strip()
            titleCA = ''.join((c for c in unicodedata.normalize('NFD', titleCA) if unicodedata.category(c) != 'Mn'))

            if titleCA[-1:] == '.':
                titleCA = titleCA[:-1]

            try:
                titleCA = re.sub('\&amp\;', '', titleCA).strip()
            except:
                pass

            print 'titleCA = %s' % titleCA


            #print '========'
            #print 'result CA    %s =' % result

            try:
                if ' - ' in titleCA:
                    titleCAsplit = titleCA.split(' - ')

                    if '1ere' in titleCAsplit[1]:
                        titleCAsplit[1] = 'partie 1'
                    elif '2e' in titleCAsplit[1]:
                         titleCAsplit[1] = 'partie 2'
                    elif '3e' in titleCAsplit[1]:
                         titleCAsplit[1] = 'partie 3'
                    elif '4e' in titleCAsplit[1]:
                         titleCAsplit[1] = 'partie 4'
                    elif '5e' in titleCAsplit[1]:
                         titleCAsplit[1] = 'partie 5'
                    elif '6e' in titleCAsplit[1]:
                         titleCAsplit[1] = 'partie 6'
                    elif '7e' in titleCAsplit[1]:
                         titleCAsplit[1] = 'partie 7'
                    elif '8e' in titleCAsplit[1]:
                         titleCAsplit[1] = 'partie 8'
                    elif '9e' in titleCAsplit[1]:
                         titleCAsplit[1] = 'partie 9'
                else:
                    titleCAsplit = ''

                print 'titleCAsplit = %s' % titleCAsplit[0]
                print 'titleCAsplit = %s' % titleCAsplit[1]
            except:
                pass


            try:
                imdbDateSortieCA = re.compile('title="See more release dates" >(.+?)\(Canada\)', re.MULTILINE|re.DOTALL).findall(result)[0].strip()

                print imdbDateSortieCA

                imdbDateSortieCA = imdbDateSortieCA.replace('January', 'Janvier')
                imdbDateSortieCA = imdbDateSortieCA.replace('February', 'Février')
                imdbDateSortieCA = imdbDateSortieCA.replace('March', 'Mars')
                imdbDateSortieCA = imdbDateSortieCA.replace('April', 'Avril')
                imdbDateSortieCA = imdbDateSortieCA.replace('May', 'Mai')
                imdbDateSortieCA = imdbDateSortieCA.replace('June', 'Juin')
                imdbDateSortieCA = imdbDateSortieCA.replace('July', 'Juillet')
                imdbDateSortieCA = imdbDateSortieCA.replace('August', 'Août')
                imdbDateSortieCA = imdbDateSortieCA.replace('September', 'Septembre')
                imdbDateSortieCA = imdbDateSortieCA.replace('October', 'Octobre')
                imdbDateSortieCA = imdbDateSortieCA.replace('November', 'Novembre')
                imdbDateSortieCA = imdbDateSortieCA.replace('December', 'Décembre')
                imdbDateSortieCA = imdbDateSortieCA[-4:]

                print imdbDateSortieCA
            except:
                imdbDateSortieCA = None


            try:
                if ' - ' in titleFR or ' - ' in titleCA:
                    queryList.append(titleFR)
                    queryList.append(titleCA)
                    queryList.append(titleFRsplit[0] + ' ' + titleCAsplit[1])
                    queryList.append(titleCAsplit[0] + ' ' + titleFRsplit[1])
                else:
                    queryList.append(titleFR)
                    queryList.append(titleCA)

                print 'queryList = %s' % queryList

            except:
                pass

            for i in queryList:

                print i

                query = i
                query = re.sub('(\\\|/|:|;|\*|\?|"|<|>|\|)', '', query)
                query = self.search_link % urllib.quote_plus(query)
                query = urlparse.urljoin(self.base_link, query)

                print 'query = %s' %query

                result = client.source(query)

                try:
                    resultAucunResultat = re.compile('<div class=\"info\">La recherche n a retourn(.+?)</div>').findall(result)[0]
                    print 'pas trouve'
                except:
                    break


            result = re.compile('<b> #(.+?)</a>').findall(result)[0]
            result = re.compile('<a href=\"(.+?)\"').findall(result)[0]

            print result

            result = client.source(result)

            result3 = re.compile('<tr><td>Taille</td><td>(.+?)</font></a></b></center></td>', re.MULTILINE|re.DOTALL).findall(result)
            result4 = [s for s in result3 if '.part' not in s.lower() and 'partie' not in s.lower() and '.rar' not in s.lower() and ' RAR' not in s and
                       'telecharger.html' not in s.lower() and 'streaming.php?' not in s.lower()]

            print result4

            for i in result4:

                try:
                    size = re.compile('>(.+?)<').findall(i)[0]
                except:
                    size = ''

                if 'x' in size.lower():
                    continue

                try:
                    language = re.compile('<img alt=\"(.+?)\"').findall(i)[0]
                except:
                    language = ''

                try:
                    quality = re.compile('<tr><td>Qualite</td><td>(.+?)/font>').findall(i)[0]
                    quality = re.compile('>(.+?)<').findall(quality)[0]
                except:
                    quality = ''

                try:
                    url = re.compile('<td align=center><center><b><a target=\"_blank\" href=\"(.+?)\"><font color=', re.MULTILINE|re.DOTALL).findall(i)[0]
                except:
                    url = ''

                if '720p' in quality.lower() or '720p' in url.lower():
                    quality = 'HD'
                elif '1080p' in quality.lower() or '1080p' in url.lower():
                    quality = '1080p'
                else:
                    quality = 'SD'


                print size, language, quality, url
                print '----------'

                host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
                #if not host in hostprDict: raise Exception()
                host = client.replaceHTMLCodes(host)
                host = host.encode('utf-8')
                #if host in hostDict:

                sources.append({'source': host, 'quality': quality, 'provider': 'Telechargementzstreaming', 'info': size + '|' + language + '|' + url, 'url': url, 'direct': False, 'debridonly': True})

            sourcesTemp = [s for s in sources if '.rar' not in s]
            sources = sourcesTemp

            #print sourcesTemp
            print sources

            return sources
        except:
            return sources


    def resolve(self, url):
        print 'RESOLVE'
        return url